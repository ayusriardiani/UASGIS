package com.example.uassigrestourant;

public class latlng {
}
