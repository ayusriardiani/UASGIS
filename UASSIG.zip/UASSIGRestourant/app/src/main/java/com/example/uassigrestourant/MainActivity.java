package com.example.uassigrestourant;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button map,list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        map= findViewById(R.id.btnmap);
        list= findViewById(R.id.btnlist);
        map.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        Intent pindahpeta = new Intent( MainActivity.this, MapsActivity.class);
        startActivity(pindahpeta);

    }
}